tisean() {
export PATH="/usr/lib/tisean":"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
}
